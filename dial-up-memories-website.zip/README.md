# Dial-Up Memories — nostalgic music website

## Folder structure

dial-up-memories/
├── index.html
├── style.css
├── script.js
└── assets/
    └── song.mp3

## Run locally

Because browsers can block local audio/file behavior, use a tiny local server.

If Python is installed:
    python3 -m http.server 8000

Then open:
    http://localhost:8000

## Add your music

Put your licensed/owned audio file at:
    assets/song.mp3

Then edit `lyricCues` in `script.js` with the exact timestamps and lyrics you are licensed to display.

## Deploy

### Netlify
1. Create a Netlify account.
2. Drag the entire `dial-up-memories` folder into Netlify Drop.
3. Netlify gives you a public URL.

### GitHub Pages
1. Create a GitHub repository.
2. Upload all files and the `assets` folder.
3. Open Settings → Pages.
4. Choose the main branch as the deployment source.
5. GitHub provides the website URL.

### Vercel
1. Create a Vercel account.
2. Import your GitHub repository.
3. Deploy.
4. Vercel provides the public URL.

No backend is required for this version.
