const startBtn = document.getElementById("startBtn");
const startScreen = document.getElementById("startScreen");
const musicScreen = document.getElementById("musicScreen");
const audio = document.getElementById("audio");
const lyricsBox = document.getElementById("lyrics");
const progressFill = document.getElementById("progressFill");
const timeBox = document.getElementById("time");
const playPause = document.getElementById("playPause");
const muteBtn = document.getElementById("muteBtn");
const dialup = document.getElementById("dialup");

/*
  Put your own audio file at:
  assets/song.mp3

  IMPORTANT:
  Use music you own or have permission to use.
  Replace the demo lyrics/timestamps below with lyrics you are licensed to display.
*/
audio.src = "assets/song.mp3";

const lyricCues = [
  { time: 0, text: "Your first lyric line goes here." },
  { time: 4, text: "Your second lyric line goes here." },
  { time: 8, text: "Your third lyric line goes here." },
  { time: 12, text: "Your fourth lyric line goes here." },
  { time: 16, text: "And the memory keeps playing..." }
];

let currentCue = -1;

function renderLyric(index) {
  if (index === currentCue) return;
  currentCue = index;
  if (index < 0) {
    lyricsBox.innerHTML = "";
    return;
  }
  lyricsBox.innerHTML = `
    <div class="lyric-line">${escapeHtml(lyricCues[index].text)}</div>
    <div class="lyric-note">1999 • connected</div>
  `;
}

function escapeHtml(text) {
  return text.replace(/[&<>"']/g, c => ({
    "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#039;"
  }[c]));
}

function update() {
  const t = audio.currentTime || 0;
  const duration = audio.duration || 1;
  progressFill.style.width = `${(t / duration) * 100}%`;
  const mins = Math.floor(t / 60).toString().padStart(2, "0");
  const secs = Math.floor(t % 60).toString().padStart(2, "0");
  timeBox.textContent = `${mins}:${secs}`;

  let cue = -1;
  for (let i = 0; i < lyricCues.length; i++) {
    if (t >= lyricCues[i].time) cue = i;
  }
  renderLyric(cue);
}

startBtn.addEventListener("click", async () => {
  startScreen.classList.add("hidden");
  musicScreen.classList.remove("hidden");
  musicScreen.classList.add("playing");
  dialup.textContent = "Connected ✓";

  try {
    await audio.play();
  } catch {
    playPause.textContent = "▶";
  }
});

playPause.addEventListener("click", async () => {
  if (audio.paused) {
    await audio.play();
    musicScreen.classList.add("playing");
    playPause.textContent = "Ⅱ";
  } else {
    audio.pause();
    musicScreen.classList.remove("playing");
    playPause.textContent = "▶";
  }
});

muteBtn.addEventListener("click", () => {
  audio.muted = !audio.muted;
  muteBtn.textContent = audio.muted ? "🔇" : "🔊";
});

audio.addEventListener("play", () => {
  musicScreen.classList.add("playing");
  playPause.textContent = "Ⅱ";
});
audio.addEventListener("pause", () => {
  musicScreen.classList.remove("playing");
  playPause.textContent = "▶";
});
audio.addEventListener("timeupdate", update);
audio.addEventListener("ended", () => {
  currentCue = -1;
  renderLyric(-1);
});
